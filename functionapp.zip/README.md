# PUBLICAR CADA SLOT

az functionapp deployment source config-zip \
    --resource-group <tu-rg> \
    --name func-learning-2025 \
    --src ./functionapp.zip \
    --slot dev

### Desarrollo
az functionapp deployment source config-zip \
    --resource-group rg-learning-az \
    --name func-learning-2025 \
    --src ./functionapp.zip \
    --slot dev

### Staging:
az functionapp deployment source config-zip \
    --resource-group rg-learning-az \
    --name func-learning-2025 \
    --src ./functionapp.zip \
    --slot staging

### Producción es el predeterminado:

az functionapp deployment source config-zip \
    --resource-group rg-learning-az \
    --name func-learning-2025 \
    --src ./functionapp.zip
